#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <malloc.h>
#include <math.h>

// #include "mergeSort.c"
// #include "quickSort.c"
// #include "utils.c"

// Discentes: Igor Rocha e Isabelle Cruz

// ALGORITHMS
void swap(int *a, int *b) {
    int t = *a;
    *a = *b;
    *b = t;
}

int partition(int array[], int low, int high, long long int* comparisons, long long int* movements) {
    // Pivot is on the right
    int pivot = array[high];

    int i = (low - 1);

    for (int j = low; j < high; j++) {
        (*comparisons)++;
        if (array[j] < pivot) {
            i++;
            swap(&array[i], &array[j]);
            (*movements)++;
        }
    }

    // swap the pivot element with the greater element at i
    swap(&array[i + 1], &array[high]);

    // return the partition point
    return (i + 1);
}

void quickSortRecursive(int array[], int low, int high, long long int* comparisons, long long int* movements) {
    if (low < high) {
        int pi = partition(array, low, high, comparisons, movements);

        // Recursive call on left
        quickSortRecursive(array, low, pi - 1, comparisons, movements);

        // Recursive call on right
        quickSortRecursive(array, pi + 1, high, comparisons, movements);
    }
}

void merge(int arr[], int p, int q, int r, long long int* comparisons, long long int* movements) {
    // Create L ← A[p..q] and M ← A[q+1..r]
    int n1 = q - p + 1;
    int n2 = r - q;
    int L[n1], M[n2];

    for (int i = 0; i < n1; i++)
        L[i] = arr[p + i];
    for (int j = 0; j < n2; j++)
        M[j] = arr[q + 1 + j];

    // Maintain current index of sub-arrays and main array
    int i = 0, j = 0, k = p;

    // Until we reach either end of either L or M, pick larger among
    // elements L and M and place them in the correct position at A[p..r]
    while (i < n1 && j < n2) {
        (*comparisons)++;
        if (L[i] <= M[j]) {
            arr[k] = L[i];
            i++;
            (*movements)++;
        } else {
            arr[k] = M[j];
            j++;
            (*movements)++;
        }
        k++;
    }
    
    // When we run out of elements in either L or M,
    // pick up the remaining elements and put in A[p..r]
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
        (*movements)++;
    }
    while (j < n2) {
        arr[k] = M[j];
        j++;
        k++;
        (*movements)++;
    }
}

void mergeSortRecursive(int arr[], int l, int r, long long int* comparisons, long long int* movements) {
    if (l < r) {
        // m is the point where the array is divided into two subarrays
        int m = l + (r - l) / 2;
        mergeSortRecursive(arr, l, m, comparisons, movements);
        mergeSortRecursive(arr, m + 1, r, comparisons, movements);
        // Merge the sorted subarrays
        merge(arr, l, m, r, comparisons, movements);
    }
}


void bubbleSort(int array[], int len) {
    long long int comparisons = 0, movements = 0;

    for (int i = 0; i < len - 1; i++) {
        for (int j = 0; j < len - i - 1; j++) {
            // Verify if not in ascending order
            comparisons++;
            if (array[j] > array[j + 1]) {
                int temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
                movements++;
            }
        }
    }

    printf("Algorithm: BubbleSort\n");
    printf("Comparisons = %lld\n", comparisons);
    printf("Movements = %lld\n", movements);
}

void quickSort(int array[], int len) {
    long long int comparisons = 0, movements = 0;

    quickSortRecursive(array, 0, len - 1, &comparisons, &movements);

    printf("Algorithm: QuickSort\n");
    printf("Comparisons = %lld\n", comparisons);
    printf("Movements = %lld\n", movements);
}

void mergeSort(int array[], int length) {
    long long int comparisons = 0, movements = 0;

    mergeSortRecursive(array, 0, length - 1, &comparisons, &movements);

    printf("Algorithm: MergeSort\n");
    printf("Comparisons = %lld\n", comparisons);
    printf("Movements = %lld\n", movements);
}

// UTILS
char *intToString(int number) {
    char *str = malloc(sizeof(char) * 20);
    sprintf(str, "%d", number);
    return str;
}

int stringToInt(char *string) {
    return atoi(string);
}

char *setFileName(char letter, int size) {
    char *string = malloc(sizeof(char) * 20);
    char newLetter[2] = {letter};
    string[0] = '\0';
    strcat(string, newLetter);
    strcat(string, "_");
    strcat(string, intToString(size));
    strcat(string, ".txt");
    return string;
}

void printArray(int array[], int len) {
    for (int i = 0; i < len; i++) {
        printf("[%d]", array[i]);
    }
    printf("\n");
}

int *getArrayFromFile(char *filename, int length) {
    FILE *file;
    int *array = malloc(sizeof(int) * (length + 1));
    char *line = NULL;
    size_t len = 0;
    size_t read;

    file = fopen(filename, "r");
    if (file == NULL) {
        return NULL;
    }

    int i = 0;
    while ((read = getline(&line, &len, file)) != -1) {
        array[i++] = stringToInt(line);
    }

    fclose(file);
    if (line) {
        free(line);
    }

    return array;
}

int main() {
    int *array;
    int length = 10;
    char *filename;

    int aux = 1;
    char availableLetters[3] = {'A', 'C', 'D'};
    int currentLetter = 0;

    for (int i = 0; i < 12; i++) {
        if (i % 4 == 0 && i != 0) {
            length = 10;
            aux = 1;
            currentLetter++;
            if(currentLetter >= 3){
                currentLetter = 0;
            }
        }
        length *= pow(10, aux);
        filename = setFileName(availableLetters[currentLetter], length);
        array = getArrayFromFile(filename, length);

        printf("-------------\n");
        printf("Current File: \"%s\"\n", filename);
        // printArray(array, length);

        clock_t start = clock();

        // Change to mergeSort/quickSort/bubbleSort
        mergeSort(array, length);

        clock_t finish = clock();

        double time_spent = (double)(finish - start) / CLOCKS_PER_SEC;

        printf("Time spent: %lfs\n", time_spent);
        // printArray(array, length);
        printf("-------------\n");

        free(array);
    }

    return 0;
}