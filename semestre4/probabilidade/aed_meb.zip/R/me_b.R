#Nilo Fernandes Varela
#Medidas Estat�sticas
#2014.2

#Media aritim�tica-------------------------------------------
  #N�o agrupado
      y<-c(3,7,8,10,11)
      y
      mean(y)
  #Agrupado                
      y<-c(1,2,2,2,3,3,3,3,3,4)
      y
      table(y)
      mean(y)

#Media Geral ------------------------------------------------
      y1<-c(4:8)
      y2<-c(1:3)
      y3<-c(9:13)      
      y1
      y2
      y3
     
      medGeral<-function(y1,y2,y3){
      (length(y1)*mean(y1)+length(y2)*mean(y2)+length(y3)*mean(y3))/(length(y1)+length(y2)+length(y3))
      }
      
      medGeral(y1,y2,y3)                                 
    
#Media Geom�trica ------------------------------------------------
      y<-c(3,6,12,24,48)
      (prod(y)^(1/length(y)))
      
      
      #Aplica��o
      #Suponha que l � a produ��o uma laranjeira por ano
      l<-c(100,180,210,300) 
      cresc<-c(80, 16.66, 42.9)
      #Aumento de 80%=multiplicar por 1.8      
      cresc<-cresc/100+1
      cresc 
      
      #aplica aumento percentual
      apliCrescimento <- function(ini, med, qtd){ 
      for(i in 1:qtd) ini <-ini*med    
      return(ini)
      }
      
      #ERRO
      medArit<-mean(cresc)
      medArit                                          
      apliCrescimento(100,medArit,3)

      #Correto
      medGeom<-(prod(cresc)^(1/length(cresc)))     
      medGeom                                          
      apliCrescimento(100,medGeom,3)
      
      
#Media Harm�nica ------------------------------------------------
      y<-c(2,5,8)
      length(y)/(sum(1/y))
 
#Mediana -------------------------------------------------------- 
      y<-c(1,2,2,2,3,3,3,3,3,4,4)
      median(y)      
     
#Moda ----------------------------------------------------------- 
      y<-read.table("./dados/dad_moda.txt", head=F)$V1;
      y
      table(y)
      modaMax<-max(table(y))
      modaMax
      table(y)[table(y)==modaMax]        
     

#Quantis ----------------------------------------------------------
      y<-sample(1:10, 10, replace=T)
      y
      quantile(y)

   #Quartis
      quantile( y, seq(.25,.75,by=0.25) )
   #Decis
      quantile( y, seq(0,1,by=0.1))
   #Percentis
      quantile( y, seq(0,1,by=0.01))
      
      boxplot(y)
      median(y)
      
      
      y<-rnorm(1e4, 100, 2)
      boxplot(y)
      
      #fun��o que remove outliers da amostra
      rmvOutl<-function(y){
         while(1){
           quartis<-quantile(y, seq(.25,.75,by=0.25))   
           ampltQuart <- quartis[3]-quartis[1]         
           outSup<-quartis[3]+ampltQuart*1.5
           outInf<-quartis[1]-ampltQuart*1.5
           if(length(y[y>outSup])==0 & length(y[y<outInf])==0){
            return(y)
           }
           y<-y[y<=outSup & y>=outInf]               
         }           
      }
      
      y<-rmvOutl(y)
      boxplot(y)
                                   
#Amplitude--------------------------------------------------------  
     y<-c(10, 12, 20, 22, 25, 33, 38)
     diff(range(y))  
#Desvio--------------------------------------------------------    
     y<-(3:7)
     y
     desvios<-(y-mean(y))
     desvios
     sum(desvios)

     
     y<-sample(1:100, 100, replace=F)
     y     
     desvios<-(y-mean(y))
     desvios
     sum(desvios)  
     
     y<-sample(1:10, 100, replace=T)
     y 
     #erro
     desvios<-(y-mean(y))
     desvios
     sum(desvios)  
     
     #correto         
     unicos<-unique(y)
     unicos
     desvios<-(unicos-mean(unicos))
     desvios
     sum(desvios)
          
     plot(sort(desvios), type='l')

   #Desvio m�dio
     y<-c(2.0,1.2,2.1,1.6,0.9,2.2,1.8) 
     med<-mean(y)
     med
     (sum(abs(y-med)))/length(y)
     
   #Desvio quadr�tico m�dio
     (sum(abs(y-med)^2))/length(y)
     
   #Vari�ncia
      x<-c(1.8, 1.7, 1.7, 1.7, 1.5, 1.7, 1.5)
      var(x)
      var(y)
     plot(y, type='h')
     plot(x, type='h')
   
   #Desvio padr�o   
     desvioPadrao<-sd(y) 
     desvioPadrao
   #Coeficiente de varia��o
     (desvioPadrao/mean(y))*100
     
   #pacote psych
     library(psych)
     y<-sample(1:40, 100, replace=T)
     describe(y)
