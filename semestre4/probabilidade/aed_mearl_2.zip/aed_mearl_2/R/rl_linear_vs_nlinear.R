##===============================================================================
## T�tulo   : An�lise quantitativa de dados - AQE
## Autor    : Jos� Cl�udio Faria/UESC/DCET
## Data     : 2018/08/13 - 09:41:13
## Vers�o   : v3
## Objetivos:
##===============================================================================
## a) Apresentar os recursos b�sicos do R para an�lise de regress�o
## b) Fundamenta��o em regress�o linear
## c) Distin��o dos modelos lineares dos n�o lineares
##===============================================================================

##===============================================================================
## Verificando se um modelo � ou n�o linear nos par�metros
##===============================================================================
fl <- expression(a + b*x)            # polin�mio de grau I
fq <- expression(a + b1*x + b2*x^2)  # polin�mio de grau II
fe <- expression(a*exp(x/b))         # Exponencial - n�o linear

# Observar que as derivadas N�O DEPENDEM do par�metro b -> Linear  -> lm
deriv(fl,
      c('a',
        'b'))

# Observar que as derivadas N�O DEPENDEM dos par�metros b1 e b2 -> Linear -> lm
deriv(fq,
      c('a',
        'b1',
        'b2'))

# Observar que as derivadas DEPENDEM do par�metro b1 -> N�o linear -> nls
deriv(fe,
      c('a',
        'b'))

