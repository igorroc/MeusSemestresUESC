##===============================================================================
## T�tulo   : An�lise quantitativa de dados - Ajustamento
## Autor    : Jos� Cl�udio Faria/UESC/DCET
## Data     : 2018/08/13 - 09:40:10
## Vers�o   : v3
## Objetivos:
##===============================================================================
## a) Apresentar os recursos b�sicos do R para an�lise de regress�o
## b) Fundamenta��o em regress�o linear simples
## c) Fundamenta��o em �lgebra de matrizes
##===============================================================================

##===============================================================================
## �nfase em �lgebra de matrizes
## +----------------------+
## |             -1       |
## | b_est = (X'X) . X'Y  |
## +----------------------+
## b_est: solu��o matricial do m�todo dos m�nimos quadrados dos erros.
## Opera��es matriciais permitem a obten��o das estimativas (b_est) dos par�metros 
## dos modelos lineares.
##===============================================================================

x <- c(10, 20, 30, 40, 50, 60, 70)
y <- c(1000, 2300, 3600, 4500, 5400, 5800, 5600)

(X <- cbind(1, x))        # Modelo linear de 1 grau: com intercepto
# (X <- cbind(x))           # Modelo linear de 1 grau: for�ando para a origem
# (X <- cbind(1, x, x^2))   # Modelo linear de 2 grau: com intercepto
# (X <- cbind(x, x^2))      # Modelo linear de 2 grau: for�ando para a origem

(Y <- cbind(y))

(XlX     <- t(X) %*% X)      # X'X

                             #     -1
(XlX_inv <- solve(XlX))      # (X'X) 

(XlY     <- t(X) %*% Y)      #  X'Y

                             #      -1     
(b_est   <- XlX_inv %*% XlY) # (X'X) . X'Y

(Y_est   <- X %*% b_est)     # Ys estimados pelo modelo ajustado

(res     <- Y - Y_est)       # Erros

# Visualizando os dados
plot(y ~ x,
     xlim=c(0, 70),
     ylim=c(0, 7000),
     pch=19,
     col='darkgreen')

# Sobrepondo os valores estimados pelo modelo ajustado (curva suavizada)
lines(spline(Y_est ~ x),
      col='red')

points(Y_est ~ x,
       col='red',
       pch=19)


##===============================================================================
## �nfase na fun��o de alto n�vel do R - lm (package:stats)
##===============================================================================
rl <- lm(y ~ x)               # Modelo linear de 1 grau: com intercepto
# rl <- lm(y ~ 0 + x)           # Modelo linear de 1 grau: for�ando para a origem 
# rl <- lm(y ~ x + I(x^2))      # Modelo linear de 2 grau: com intercepto                        
# rl <- lm(y ~ 0 + x + I(x^2))  # Modelo linear de 2 grau: for�ando para a origem                       

summary(rl)
class(rl)
mode(rl)
names(rl)

# Visualizando os dados
plot(y ~ x,
     xlim=c(0, 70),
     ylim=c(0, 7000),
     pch=19,
     col='darkgreen')

# Sobrepondo o modelo ajustado
lines(spline(fitted(rl) ~ x,
             n=1e2),
      col='red')

points(fitted(rl) ~ x,
       col='red',
       pch=19)

##===============================================================================
# Verificando apresenta��o gr�fica com todos os modelos
##===============================================================================
plot(y ~ x,
     xlim=c(0, 70),
     ylim=c(0, 7000),
     pch=19,
     col='darkgreen')

# Modelo linear de 1 grau: com intercepto
lines(fitted(lm(y ~ x)) ~ x,
      col='blue')

# Modelo linear de 1 grau: ajustado para a origem
lines(fitted(lm(y ~ 0 + x)) ~ x,
      col='blue',
      lty=2)

# Modelo linear de 2 grau: com intercepto
lines(spline(fitted(lm(y ~ x + I(x^2))) ~ x,
             n=1e2),
      col='red',
      lw=2)

# Modelo linear de 2 grau: ajustado para a origem
lines(spline(fitted(lm(y ~ 0 + x + I(x^2))) ~ x, 
             n=1e2),
      col='red',
      lw=2,
      lty=2)

legend('topleft',
       title='Polin�mios de grau',
       c('I',
         'I (ajustado p/ origem)',
         'II',
         'II (ajustado p/ origem)'),
       lty=c(1, 2, 1, 2),
       col=c('blue', 'blue', 'red', 'red'),
       bg = gray(.9),
       lwd=c(1, 2, 1, 2))
