X <- c(2, 6, 8, 8, 12, 16, 20, 20, 22, 26)
Y <- c(58, 105, 88, 118, 117, 137, 157, 169, 149, 202)

b0 <- seq(-50, 
          250, 
          by=10)

b1 <- seq(-8, 
          22, 
          by=1)

SQDerro <- array(dim=c(length(b0), 
                       length(b1)))

dimnames(SQDerro) <- list(b0, b1)

for (i in 1:length(b0)){
  for (j in 1:length(b1)){
    Yest <- b0[i] + b1[j]*X
    SQDerro[i,j] <- sum((Y - Yest)^2)    
  }
}

b0_m <- rep(b0, 
            each=length(b0))

b1_m <- rep(b1, 
            length(b1))

library(scatterplot3d)
scp <- scatterplot3d(b0_m, 
                     b1_m, 
                     SQDerro,
                     lab=c(15, 7),
                     lab.z=3,
                     xlab='b0', 
                     ylab='b1', 
                     box=F,
                     highlight.3d=TRUE,
                     #color=gray(.4),
                     col.grid=gray(.6),
                     bg='red',
                     pch=20,
                     angle=45,
                     scale.y=.3,
                     asp=NA,
                     cex.symbols=.8)
scp$points3d(60, 
             5, 
             1530,
             pch=19,
             cex=2,
             col='blue')                     


#surface3d(b0, 
#          b1, 
#          SQDerro)

#b0 <- seq(-50, 
#          250, 
#          by=10)
#
#b1 <- seq(-8, 
#          22, 
#          by=1)
#          
#SQDerro <- array(dim=c(length(b1), length(b0)))
#SQDerro <- matrix(ncol=31, nrow=31)
#
#for(i in length(b0)){
#  for(j in length(b1)){
#    print(paste(i, j, sep=' '))
#  }
#}
#
#
#
#
#    for (i in bo){
#      Yvbo <- i + Buser[2]*X
#
#      SQDerro_bo <- c(SQDerro_bo, 
#                   sum((Y - Yvbo)^2))
#    }
#
#
#    Buser <- c(0, -4)
#    
#    SQDerro_bo <- numeric()
#
#
#    SQDerro_b1 <- numeric()
#
#
#    for (i in b1){
#      Yvb1 <- Buser[1] + i*X
#
#      SQDerro_b1 <- c(SQDerro_b1, 
#                   sum((Y - Yvb1)^2))
#    }
#
#str(scatterplot3d)
#
#              layout
#scatterplot3d(x=b0, 
#              y=b1, 
#              z= Z)
#              