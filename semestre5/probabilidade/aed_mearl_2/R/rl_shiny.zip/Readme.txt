Material de apoio para semin�rio de RL

Este material de apoio � bem interessante (e raro).
Foi feito para auxiliar o processo de entendimento de ajustamento via minimiza��o de erros.

Passos:
1- Instale o pacote shiny no R:
  > install.packages('shiny', dep=T)

2- Descompacte o arquivo reg_shiny.zip em anexo em alguma pasta;

3- Altere o diret�rio de trabalho do R para a pasta onde descompactou os arquivo em anexo:
  > setwd('nome da pasta')

4- Carregue o pacote shiny:
  > library(shiny)

5- No console digite:
  > runApp()

Vai abrir no navegador default do sistema operacional uma p�gina em que se pode interagir nas caixinhas do canto superior esquerdo.

Quando quiser interromper basta fechar a aba do navegador que o console do R ficar� liberado novamente.

Se tiver dificuldade com o Rterm do Tinn-R tente com o Rgui.
No Rgui, para encerrar pode-se digitar CTRL + C no console do Rgui.exe ou fechar o navegador.
