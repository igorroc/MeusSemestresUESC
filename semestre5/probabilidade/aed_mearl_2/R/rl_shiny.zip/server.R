#===============================================================================
# Name   : Estimativa de parâmetros de regressão linear simples
# Author : Ivan B. Allaman e J.C.Faria
# Date   : 22/12/2017 21:31:27
# Version: v4
# Aim    : Facilitar o entendimento dos métodos dos mínimos quadrados dos erros
# Mail   : <<<joseclaudio.faria@gmail.com>>>
#===============================================================================

require(shiny)

shinyServer(function(input, output, session)
{
  session$onSessionEnded(function()
  {
    stopApp()
  })

  output$betas <- renderPlot(
  {
    X <- c(2, 6, 8, 8, 12, 16, 20, 20, 22, 26)
    Y <- c(58, 105, 88, 118, 117, 137, 157, 169, 149, 202)

    Buser <- c(input$bo,
               input$b1)

    Yest <- Buser[1] + Buser[2]*X

    erro <- sum((Y - Yest)^2)

    rl <- lm(Y ~ X)

    m <- matrix(c(1, 2, 2,
                  1, 3, 4),
                 nrow=2,
                 ncol=3, byrow=T)

    layout(m)

    #par(mai=c(1, 1, .5, .5))
    plot(X, Y,
         bty='n',
         #box=FALSE,
         pch=19,
         cex=2,
         xlim=c(-5, 30),
         ylim=c(-10, 300),
         cex.lab=1.5)

    abline(a=Buser[1],
           b=Buser[2],
           col='blue',
           lwd=2)

    # Sobrepondo o modelo ajustado
    if(input$mostrar_ajuste)
      lines(fitted(rl) ~ X,
            col='darkgreen',
            lw=2.5)


    n <- length(X)
    segments(X[1:n], 
             Y[1:n], 
             X[1:n], 
             Yest[1:n], 
             lty=2,
             col=ifelse(Y > Yest,
                        gray(.5),
                        'red'))
             
    # Soma de quadrado dos erros
    mtext(bquote(SQ[erro] == .(erro)), 
          col='red',
          cex=1.5,
          line=1)

    # Equação do usuário
    mtext(bquote(hat(Y) == .(Buser[1]) + 
                           .(Buser[2])*X), 
          line= -3,
          col='blue',
          cex=1.5)

    # Equação de mínimos quadrados dos erros
    if(input$mostrar_ajuste)
      mtext(bquote(hat(Y) == .(coef(rl)[1]) +
                             .(coef(rl)[2])*X),
            line=-6,
            col='darkgreen',
            cex=1.5)

    #------------------------------------------------------------------
    # Superfície de resposta
    #------------------------------------------------------------------
    b0 <- seq(-100,
               500,
               by=10)

    b1 <- seq(-5,
              25,
              by=.5)

    SQDerro <- array(dim=c(length(b0),
                           length(b1)))
    
    dimnames(SQDerro) <- list(b0, b1)
    
    for (i in 1:length(b0)){
      for (j in 1:length(b1)){
        Yest <- b0[i] + b1[j]*X
        SQDerro[i,j] <- sum((Y - Yest)^2)    
      }
    }
    
    b0_plot <- rep(b0, 
                   each=length(b0))
    
    b1_plot <- rep(b1, 
                   length(b1))
    
    require(scatterplot3d)

    #par(mai=c(0, 1, .5, .5))
    scp <- scatterplot3d(b0_plot,
                         b1_plot,
                         SQDerro,
                         bty='n',
                         #lab=c(9, 1),
                         lab.z=2,
                         zlim=c(0, 1e6),
                         xlab='b0', 
                         ylab='b1', 
                         box=F,
                         highlight.3d=TRUE,
                         #color=gray(.4),
                         #col.grid=gray(.6),
                         grid=FALSE,
                         bg='red',
                         pch=20,
                         angle=55,
                         scale.y=.4,
                         cex.symbols=.1)

    mtext(bquote(hat(Y) == .(Buser[1]) +
                           .(Buser[2])*X),
          line=1,
          col='red',
          cex=1.5)

    Yest <- Buser[1] + Buser[2]*X
    SQDerro <- sum((Y - Yest)^2)

    scp$points3d(Buser[1],
                 Buser[2], 
                 SQDerro,
                 pch=19,
                 cex=3,
                 col='blue')                     

#------------------------------------------------------------------
# SQD ~ bo
# Para cada valor que o usuário altera de b1
# Faz a curva SQD ~ bo
#------------------------------------------------------------------
    SQDerro <- numeric()

    bo <- seq(-100,
               400,
              by=10)

    for (i in bo){
      Yvbo <- i + Buser[2]*X

      SQDerro <- c(SQDerro, 
                   sum((Y - Yvbo)^2))
    }
    
    par(mai=c(.6, .6, .5, .5))
    plot(SQDerro ~ bo,
         type='b',
         bty='n',
         #box=FALSE,
         ylim=c(0, 6e5),
         col=gray(.6),
         pch=19,
         lty=3,
         cex=1.5,
         cex.lab=1.5,
         ylab= paste('SQDerro rel. b0 p/ b1',
                     Buser[2],
                     sep=' = '))

    mtext(bquote(b[0] == .(Buser[1])),
          col='red',
          cex=1.5,
          line=1)

    abline(v=Buser[1],
           lty=2,
           col=gray(.7))

    abline(h=erro,
           lty=2,
           col=gray(.7))

#------------------------------------------------------------------
# SQD ~ b1
# Para cada valor que o usuário altera de b0
# Faz a curva SQD ~ b1
#------------------------------------------------------------------
    SQDerro <- numeric()

    b1 <- seq(-5,
              25,
              by=1)

    for (i in b1){
      Yvb1 <- Buser[1] + i*X

      SQDerro <- c(SQDerro, 
                   sum((Y - Yvb1)^2))
    }
    
    #par(mai=c(0, 2, 1, 1))
    plot(SQDerro ~ b1,
         bty='n',
#         box=FALSE,
         ylim=c(0, 6e5),
         pch=19,
         col=gray(.6),
         type='b',
         lty=3,
         cex=1.5,
         cex.lab=1.5,
         ylab= paste('SQDerro rel. b1 p/ b0',
                     Buser[1],
                     sep=' = '))
    
    mtext(bquote(b[1] == .(Buser[2])),
          col='red',
          cex=1.5,
          line=1)

    abline(v=Buser[2],
           lty=2,
           col=gray(.7))

    abline(h=erro,
           lty=2,
           col=gray(.7))
  })
})
