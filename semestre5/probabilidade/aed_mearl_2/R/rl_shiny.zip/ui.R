#===============================================================================
# Name   : Estimativa de parâmetros de regressão linear simples
# Author : Ivan B. Allaman e J.C.Faria
# Date   : 17/12/2017 20:43:04
# Version: V.3
# Aim    : Facilitar o entendimento dos métodos dos mínimos quadrados dos erros
# Mail   : <<<joseclaudio.faria@gmail.com>>>
#===============================================================================

library(shiny)

# Define UI for dataset viewer application
shinyUI(
  pageWithSidebar(
    headerPanel(
      title='Est. parâmetros',
      windowTitle='Regressão Linear'),    
    
    sidebarPanel(
      sliderInput('bo', 
                  HTML('&beta;<SUB>0</SUB>'), 
                  animate=TRUE,
                  min=0, 
                  max=250,
                  step=10,
                  value=0),
    
      sliderInput('b1', 
                  HTML('&beta;<SUB>1</SUB>'), 
                  animate=TRUE,
                  min=-5,
                  max=25,
                  step=1,
                  value=0),

      checkboxInput('mostrar_ajuste',
                    'Mostrar equação e reta ótima ajustada'),

      width=3),

    mainPanel(
      plotOutput(
        'betas',
        height='500px'))
  ) # pageWithSidebar
) # shinyUI
