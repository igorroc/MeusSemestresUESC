public class Retangulo {
        private float base;
        private float altura;

        public float calcularArea() {
                return 0;
        }

        public float calcularPerimetro() {
                return 0;
        }

        public void imprimir() {
                System.out.println("A Altura é " + base);
        }

        public void setBaseEAltura(float b, float a) {
                base = b;
                altura = a;
        }

}
