## Instruções para exercício

**Este diretório contém um projeto BlueJ**

- Instale o BlueJ.
- Baixe todos os arquivos no diretório e abra o arquivo `package.bluej`.
- Implemente os métodos calcularArea( ) e testCalcularPerimetro( ).
- Tente entender a estrutura da Classe e seus membros: Atributos e Métodos.
- Modifique o método imprimir( ) para que imprima os dados em um outro formato de sua     preferência.
- Crie instâncias (objetos) desta classe e brinque com eles no BlueJ.
