## Instruções Para o Exercício

**Nota Importante:** Nosso exercícios até aqui estão todos relacionados. Os exercícios mais novos complementam os mais antigos, adicionando novos conceitos de OO.

Para a próxima aula inclua construtores em todas as classes que criou até aqui. Crie um construtor para iniciar o objeto com valores padrões e um outro com parâmetros para que seja possível iniciar o objeto já com valores desejados.

Use este código deste diretório como ponto de partida. Lembrem-se de usar a implementação do Retângulo como base para a implementação das outras formas.
