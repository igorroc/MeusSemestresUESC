## Instruções Para o Exercício

1. Use o BlueJ (deixemos o uso de outras IDEs para depois)
2. Abra este projeto, nele consta uma classe `Retangulo` e os se teste `RetanguloTest`.
3. Crie outras classes e seus respectivos testes para representar outras formas geométricas, exemplo:
  - Triângulo, Hexagono, Trapézio, etc.
4. Todas elas devem ter os mesmos métodos que existem na classe Retângulo e todos os métodos que possuam alguma lógica envolvida devem ser testadas.

Qualquer dúvidas entrar em contato por e-mail ou pelo canal no discord.
