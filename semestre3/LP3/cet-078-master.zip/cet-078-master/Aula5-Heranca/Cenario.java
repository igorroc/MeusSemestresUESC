
public class Cenario
{
    public Cenario()
    {
    }

    public void renderizar() {
    }
}
