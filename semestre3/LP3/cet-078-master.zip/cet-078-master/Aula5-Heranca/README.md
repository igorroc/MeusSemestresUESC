## Exercício de Herança

1. Leia e estude de maneira aprofundado o código que vimos na Aula 5 antes de colocar a mão na massa.
2. Entre em contato para tirar quaisquer dúvidas seja pelo Discord ou por E-mail.
3. Crie mais classes representando outros elementos do jogo além do Herói e do Monstro.
5. Implemente o cenário, ele deve conter um ou mais heróis, um ou mais monstros, além de elementos criados por você.
6. Implemente o método renderizar de todas as classes que são "renderizáveis" no cenário.
7. Implemente o método renderizar do cenário ele deve utilizar o método renderizar dos objetos que compões o cenários (ex. Heroi, Monstro, etc.)
  * Note que chamando o método renderizar de cada um dos objetos teremos toda a cena renderizada ao final de uma chamada ao método renderizar do Cenario.

  *Bom trabalho a todos*
