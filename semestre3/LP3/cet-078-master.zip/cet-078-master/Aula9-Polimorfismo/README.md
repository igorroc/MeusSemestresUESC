## Exerccício

1. Expanda o exemplo visto em sala de aula, crie os outros cargos e implemente os
métodos para calcular salário.
2. Verifique outos aspectos dos funcionários que possam utilizar polimorfimso,
implemente os métodos de forma que eles sejam polimórficos.
3. Tente identificar outros aspectos de um departamento de RH e implemente no
seu programa, necessitem eles de polimorfimso ou não.
