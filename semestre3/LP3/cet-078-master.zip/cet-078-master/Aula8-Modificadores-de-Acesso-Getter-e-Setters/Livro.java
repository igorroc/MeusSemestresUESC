
public class Livro
{
   private int id;
   private String titulo;
   private String categoria;
   private String autor;
   private int numeroDePaginas;
   
   public int getId() {
       return this.id;
   }
   
   public void setId(int id) {
       this.id = id;
   }
   
   public String getTitulo() {
       return this.titulo;
   }
   
   public void setTitulo(String titulo) {
       this.titulo = titulo;
   }
}
