## Exercício

1. Aperfeiçoe os exercícios feitos até aqui criando os métodos de acesso para os atributos das classes.
2. Em caso de herança analise possíveis atributos protected nas superclasses.
