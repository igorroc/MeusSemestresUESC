public interface Forma
{

    float calcularArea();
    
    float calcularPerimetro();
    
}
